BÀI TẬP 32 - WEBSITE PORTFOLIO 3 TRANG

1. Mở index.html bằng Chrome để xem trước.
2. QUAN TRỌNG: Thay file images/avatar.jpg bằng ảnh chân dung thật (giữ đúng tên avatar.jpg).
3. Có thể sửa tên, giới thiệu, dự án, kỹ năng ở index.html, about.html, contact.html.
4. Trong js/script.js, thay thay-email-cua-ban@example.com bằng email thật nếu muốn dùng form liên hệ.
5. Tạo repository PUBLIC tên my-portfolio trên https://github.com/new
6. Chọn Add file > Upload files, upload TOÀN BỘ NỘI DUNG thư mục my-portfolio (3 HTML, css/, js/, images/). Không để index.html lồng trong một thư mục con.
7. Vào Settings > Pages > Build and deployment > Deploy from a branch > main > /(root) > Save.
8. Link sau khi GitHub Pages bật: https://TEN-TAI-KHOAN.github.io/my-portfolio/
9. Chụp ảnh website trên trình duyệt với thanh địa chỉ URL và nộp link + source code.

LƯU Ý: Chưa đăng lên GitHub nên chưa có URL hoạt động hoặc ảnh kết quả triển khai thực tế.
