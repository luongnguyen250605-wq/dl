document.addEventListener('DOMContentLoaded', () => {
  console.log('Portfolio của Nguyễn Đức Lương đã tải xong!');
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  const form = document.getElementById('contactForm');
  if (!form) return;
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    // THAY địa chỉ dưới đây bằng email thật trước khi đăng website.
    const recipient = 'thay-email-cua-ban@example.com';
    if (recipient === 'thay-email-cua-ban@example.com') {
      document.getElementById('formStatus').textContent = 'Bạn cần thay email nhận trong js/script.js trước khi dùng biểu mẫu.';
      return;
    }
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    const subject = encodeURIComponent('Liên hệ Portfolio từ ' + name);
    const body = encodeURIComponent(`Họ tên: ${name}\nEmail: ${email}\n\n${message}`);
    window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
  });
});
